import javax.swing.JFrame;

public class Main {
    public static void main(String[] args) {
        LockerApplication lockerApp = new LockerApplication();
        lockerApp.setupFrame();
    }
}